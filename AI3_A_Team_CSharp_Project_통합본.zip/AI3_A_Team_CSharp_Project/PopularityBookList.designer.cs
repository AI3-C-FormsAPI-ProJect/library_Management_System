﻿namespace AI3_A_Team_CSharp_Project
{
    partial class PopularityBookList
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gender0 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.date1 = new System.Windows.Forms.TextBox();
            this.date2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.gender1 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.age0 = new System.Windows.Forms.CheckBox();
            this.age6 = new System.Windows.Forms.CheckBox();
            this.age8 = new System.Windows.Forms.CheckBox();
            this.age14 = new System.Windows.Forms.CheckBox();
            this.age20 = new System.Windows.Forms.CheckBox();
            this.age30 = new System.Windows.Forms.CheckBox();
            this.age40 = new System.Windows.Forms.CheckBox();
            this.age50 = new System.Windows.Forms.CheckBox();
            this.age60 = new System.Windows.Forms.CheckBox();
            this.agem1 = new System.Windows.Forms.CheckBox();
            this.gender2 = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.region11 = new System.Windows.Forms.CheckBox();
            this.region21 = new System.Windows.Forms.CheckBox();
            this.region22 = new System.Windows.Forms.CheckBox();
            this.region23 = new System.Windows.Forms.CheckBox();
            this.region24 = new System.Windows.Forms.CheckBox();
            this.region25 = new System.Windows.Forms.CheckBox();
            this.region26 = new System.Windows.Forms.CheckBox();
            this.region29 = new System.Windows.Forms.CheckBox();
            this.region31 = new System.Windows.Forms.CheckBox();
            this.region32 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.kdc0 = new System.Windows.Forms.CheckBox();
            this.kdc1 = new System.Windows.Forms.CheckBox();
            this.kdc2 = new System.Windows.Forms.CheckBox();
            this.kdc3 = new System.Windows.Forms.CheckBox();
            this.kdc4 = new System.Windows.Forms.CheckBox();
            this.kdc5 = new System.Windows.Forms.CheckBox();
            this.kdc6 = new System.Windows.Forms.CheckBox();
            this.kdc7 = new System.Windows.Forms.CheckBox();
            this.kdc8 = new System.Windows.Forms.CheckBox();
            this.kdc9 = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.pageSize50 = new System.Windows.Forms.CheckBox();
            this.pageSize100 = new System.Windows.Forms.CheckBox();
            this.pageSize200 = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.rankingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.booknameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.authorsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.publisherDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.publicationyearDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loancountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.popularityBookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popularityBookBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // gender0
            // 
            this.gender0.AutoSize = true;
            this.gender0.Location = new System.Drawing.Point(10, 188);
            this.gender0.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gender0.Name = "gender0";
            this.gender0.Size = new System.Drawing.Size(54, 19);
            this.gender0.TabIndex = 0;
            this.gender0.Text = "남성";
            this.gender0.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "대출 기간";
            // 
            // date1
            // 
            this.date1.Location = new System.Drawing.Point(12, 86);
            this.date1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.date1.Name = "date1";
            this.date1.Size = new System.Drawing.Size(100, 23);
            this.date1.TabIndex = 2;
            // 
            // date2
            // 
            this.date2.Location = new System.Drawing.Point(118, 86);
            this.date2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.date2.Name = "date2";
            this.date2.Size = new System.Drawing.Size(100, 23);
            this.date2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "시작 일";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(185, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "끝 일";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "성별";
            // 
            // gender1
            // 
            this.gender1.AutoSize = true;
            this.gender1.Location = new System.Drawing.Point(64, 188);
            this.gender1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gender1.Name = "gender1";
            this.gender1.Size = new System.Drawing.Size(54, 19);
            this.gender1.TabIndex = 7;
            this.gender1.Text = "여성";
            this.gender1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 234);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "연령";
            // 
            // age0
            // 
            this.age0.AutoSize = true;
            this.age0.Location = new System.Drawing.Point(12, 252);
            this.age0.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.age0.Name = "age0";
            this.age0.Size = new System.Drawing.Size(117, 19);
            this.age0.TabIndex = 9;
            this.age0.Text = "영유아(0~5세)";
            this.age0.UseVisualStyleBackColor = true;
            // 
            // age6
            // 
            this.age6.AutoSize = true;
            this.age6.Location = new System.Drawing.Point(116, 252);
            this.age6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.age6.Name = "age6";
            this.age6.Size = new System.Drawing.Size(103, 19);
            this.age6.TabIndex = 10;
            this.age6.Text = "유아(6~7세)";
            this.age6.UseVisualStyleBackColor = true;
            // 
            // age8
            // 
            this.age8.AutoSize = true;
            this.age8.Location = new System.Drawing.Point(213, 252);
            this.age8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.age8.Name = "age8";
            this.age8.Size = new System.Drawing.Size(110, 19);
            this.age8.TabIndex = 11;
            this.age8.Text = "초등(8~13세)";
            this.age8.UseVisualStyleBackColor = true;
            // 
            // age14
            // 
            this.age14.AutoSize = true;
            this.age14.Location = new System.Drawing.Point(316, 252);
            this.age14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.age14.Name = "age14";
            this.age14.Size = new System.Drawing.Size(131, 19);
            this.age14.TabIndex = 12;
            this.age14.Text = "청소년(14~19세)";
            this.age14.UseVisualStyleBackColor = true;
            // 
            // age20
            // 
            this.age20.AutoSize = true;
            this.age20.Location = new System.Drawing.Point(440, 252);
            this.age20.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.age20.Name = "age20";
            this.age20.Size = new System.Drawing.Size(54, 19);
            this.age20.TabIndex = 13;
            this.age20.Text = "20대";
            this.age20.UseVisualStyleBackColor = true;
            // 
            // age30
            // 
            this.age30.AutoSize = true;
            this.age30.Location = new System.Drawing.Point(12, 280);
            this.age30.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.age30.Name = "age30";
            this.age30.Size = new System.Drawing.Size(54, 19);
            this.age30.TabIndex = 14;
            this.age30.Text = "30대";
            this.age30.UseVisualStyleBackColor = true;
            // 
            // age40
            // 
            this.age40.AutoSize = true;
            this.age40.Location = new System.Drawing.Point(66, 280);
            this.age40.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.age40.Name = "age40";
            this.age40.Size = new System.Drawing.Size(54, 19);
            this.age40.TabIndex = 15;
            this.age40.Text = "40대";
            this.age40.UseVisualStyleBackColor = true;
            // 
            // age50
            // 
            this.age50.AutoSize = true;
            this.age50.Location = new System.Drawing.Point(118, 280);
            this.age50.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.age50.Name = "age50";
            this.age50.Size = new System.Drawing.Size(54, 19);
            this.age50.TabIndex = 16;
            this.age50.Text = "50대";
            this.age50.UseVisualStyleBackColor = true;
            // 
            // age60
            // 
            this.age60.AutoSize = true;
            this.age60.Location = new System.Drawing.Point(174, 280);
            this.age60.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.age60.Name = "age60";
            this.age60.Size = new System.Drawing.Size(89, 19);
            this.age60.TabIndex = 17;
            this.age60.Text = "60대 이상";
            this.age60.UseVisualStyleBackColor = true;
            // 
            // agem1
            // 
            this.agem1.AutoSize = true;
            this.agem1.Location = new System.Drawing.Point(256, 280);
            this.agem1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.agem1.Name = "agem1";
            this.agem1.Size = new System.Drawing.Size(54, 19);
            this.agem1.TabIndex = 18;
            this.agem1.Text = "미상";
            this.agem1.UseVisualStyleBackColor = true;
            // 
            // gender2
            // 
            this.gender2.AutoSize = true;
            this.gender2.Location = new System.Drawing.Point(118, 188);
            this.gender2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gender2.Name = "gender2";
            this.gender2.Size = new System.Drawing.Size(54, 19);
            this.gender2.TabIndex = 19;
            this.gender2.Text = "미상";
            this.gender2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 328);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 15);
            this.label6.TabIndex = 20;
            this.label6.Text = "지역";
            // 
            // region11
            // 
            this.region11.AutoSize = true;
            this.region11.Location = new System.Drawing.Point(12, 346);
            this.region11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region11.Name = "region11";
            this.region11.Size = new System.Drawing.Size(54, 19);
            this.region11.TabIndex = 21;
            this.region11.Text = "서울";
            this.region11.UseVisualStyleBackColor = true;
            // 
            // region21
            // 
            this.region21.AutoSize = true;
            this.region21.Location = new System.Drawing.Point(64, 346);
            this.region21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region21.Name = "region21";
            this.region21.Size = new System.Drawing.Size(54, 19);
            this.region21.TabIndex = 22;
            this.region21.Text = "부산";
            this.region21.UseVisualStyleBackColor = true;
            // 
            // region22
            // 
            this.region22.AutoSize = true;
            this.region22.Location = new System.Drawing.Point(118, 346);
            this.region22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region22.Name = "region22";
            this.region22.Size = new System.Drawing.Size(54, 19);
            this.region22.TabIndex = 23;
            this.region22.Text = "대구";
            this.region22.UseVisualStyleBackColor = true;
            // 
            // region23
            // 
            this.region23.AutoSize = true;
            this.region23.Location = new System.Drawing.Point(170, 346);
            this.region23.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region23.Name = "region23";
            this.region23.Size = new System.Drawing.Size(54, 19);
            this.region23.TabIndex = 24;
            this.region23.Text = "인천";
            this.region23.UseVisualStyleBackColor = true;
            // 
            // region24
            // 
            this.region24.AutoSize = true;
            this.region24.Location = new System.Drawing.Point(224, 346);
            this.region24.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region24.Name = "region24";
            this.region24.Size = new System.Drawing.Size(54, 19);
            this.region24.TabIndex = 25;
            this.region24.Text = "광주";
            this.region24.UseVisualStyleBackColor = true;
            // 
            // region25
            // 
            this.region25.AutoSize = true;
            this.region25.Location = new System.Drawing.Point(278, 346);
            this.region25.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region25.Name = "region25";
            this.region25.Size = new System.Drawing.Size(54, 19);
            this.region25.TabIndex = 26;
            this.region25.Text = "대전";
            this.region25.UseVisualStyleBackColor = true;
            // 
            // region26
            // 
            this.region26.AutoSize = true;
            this.region26.Location = new System.Drawing.Point(332, 346);
            this.region26.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region26.Name = "region26";
            this.region26.Size = new System.Drawing.Size(54, 19);
            this.region26.TabIndex = 27;
            this.region26.Text = "울산";
            this.region26.UseVisualStyleBackColor = true;
            // 
            // region29
            // 
            this.region29.AutoSize = true;
            this.region29.Location = new System.Drawing.Point(12, 374);
            this.region29.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region29.Name = "region29";
            this.region29.Size = new System.Drawing.Size(54, 19);
            this.region29.TabIndex = 28;
            this.region29.Text = "세종";
            this.region29.UseVisualStyleBackColor = true;
            // 
            // region31
            // 
            this.region31.AutoSize = true;
            this.region31.Location = new System.Drawing.Point(64, 374);
            this.region31.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region31.Name = "region31";
            this.region31.Size = new System.Drawing.Size(54, 19);
            this.region31.TabIndex = 29;
            this.region31.Text = "경기";
            this.region31.UseVisualStyleBackColor = true;
            // 
            // region32
            // 
            this.region32.AutoSize = true;
            this.region32.Location = new System.Drawing.Point(118, 374);
            this.region32.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.region32.Name = "region32";
            this.region32.Size = new System.Drawing.Size(54, 19);
            this.region32.TabIndex = 30;
            this.region32.Text = "강원";
            this.region32.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Location = new System.Drawing.Point(170, 374);
            this.checkBox24.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(54, 19);
            this.checkBox24.TabIndex = 31;
            this.checkBox24.Text = "충북";
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Location = new System.Drawing.Point(224, 374);
            this.checkBox25.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(54, 19);
            this.checkBox25.TabIndex = 32;
            this.checkBox25.Text = "충남";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Location = new System.Drawing.Point(278, 374);
            this.checkBox26.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(54, 19);
            this.checkBox26.TabIndex = 33;
            this.checkBox26.Text = "전북";
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Location = new System.Drawing.Point(332, 374);
            this.checkBox27.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(54, 19);
            this.checkBox27.TabIndex = 34;
            this.checkBox27.Text = "전남";
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Location = new System.Drawing.Point(12, 401);
            this.checkBox28.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(54, 19);
            this.checkBox28.TabIndex = 35;
            this.checkBox28.Text = "경북";
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Location = new System.Drawing.Point(64, 401);
            this.checkBox29.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(54, 19);
            this.checkBox29.TabIndex = 36;
            this.checkBox29.Text = "경남";
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Location = new System.Drawing.Point(118, 401);
            this.checkBox30.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(54, 19);
            this.checkBox30.TabIndex = 37;
            this.checkBox30.Text = "제주";
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 458);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 15);
            this.label7.TabIndex = 38;
            this.label7.Text = "주제";
            // 
            // kdc0
            // 
            this.kdc0.AutoSize = true;
            this.kdc0.Location = new System.Drawing.Point(10, 476);
            this.kdc0.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc0.Name = "kdc0";
            this.kdc0.Size = new System.Drawing.Size(54, 19);
            this.kdc0.TabIndex = 39;
            this.kdc0.Text = "총류";
            this.kdc0.UseVisualStyleBackColor = true;
            // 
            // kdc1
            // 
            this.kdc1.AutoSize = true;
            this.kdc1.Location = new System.Drawing.Point(64, 476);
            this.kdc1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc1.Name = "kdc1";
            this.kdc1.Size = new System.Drawing.Size(54, 19);
            this.kdc1.TabIndex = 40;
            this.kdc1.Text = "철학";
            this.kdc1.UseVisualStyleBackColor = true;
            // 
            // kdc2
            // 
            this.kdc2.AutoSize = true;
            this.kdc2.Location = new System.Drawing.Point(116, 476);
            this.kdc2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc2.Name = "kdc2";
            this.kdc2.Size = new System.Drawing.Size(54, 19);
            this.kdc2.TabIndex = 41;
            this.kdc2.Text = "종교";
            this.kdc2.UseVisualStyleBackColor = true;
            // 
            // kdc3
            // 
            this.kdc3.AutoSize = true;
            this.kdc3.Location = new System.Drawing.Point(170, 476);
            this.kdc3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc3.Name = "kdc3";
            this.kdc3.Size = new System.Drawing.Size(82, 19);
            this.kdc3.TabIndex = 42;
            this.kdc3.Text = "사회과학";
            this.kdc3.UseVisualStyleBackColor = true;
            // 
            // kdc4
            // 
            this.kdc4.AutoSize = true;
            this.kdc4.Location = new System.Drawing.Point(248, 476);
            this.kdc4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc4.Name = "kdc4";
            this.kdc4.Size = new System.Drawing.Size(82, 19);
            this.kdc4.TabIndex = 43;
            this.kdc4.Text = "자연과학";
            this.kdc4.UseVisualStyleBackColor = true;
            // 
            // kdc5
            // 
            this.kdc5.AutoSize = true;
            this.kdc5.Location = new System.Drawing.Point(326, 476);
            this.kdc5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc5.Name = "kdc5";
            this.kdc5.Size = new System.Drawing.Size(82, 19);
            this.kdc5.TabIndex = 44;
            this.kdc5.Text = "기술과학";
            this.kdc5.UseVisualStyleBackColor = true;
            // 
            // kdc6
            // 
            this.kdc6.AutoSize = true;
            this.kdc6.Location = new System.Drawing.Point(10, 504);
            this.kdc6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc6.Name = "kdc6";
            this.kdc6.Size = new System.Drawing.Size(54, 19);
            this.kdc6.TabIndex = 45;
            this.kdc6.Text = "예술";
            this.kdc6.UseVisualStyleBackColor = true;
            // 
            // kdc7
            // 
            this.kdc7.AutoSize = true;
            this.kdc7.Location = new System.Drawing.Point(64, 504);
            this.kdc7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc7.Name = "kdc7";
            this.kdc7.Size = new System.Drawing.Size(54, 19);
            this.kdc7.TabIndex = 46;
            this.kdc7.Text = "언어";
            this.kdc7.UseVisualStyleBackColor = true;
            // 
            // kdc8
            // 
            this.kdc8.AutoSize = true;
            this.kdc8.Location = new System.Drawing.Point(116, 504);
            this.kdc8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc8.Name = "kdc8";
            this.kdc8.Size = new System.Drawing.Size(54, 19);
            this.kdc8.TabIndex = 47;
            this.kdc8.Text = "문학";
            this.kdc8.UseVisualStyleBackColor = true;
            // 
            // kdc9
            // 
            this.kdc9.AutoSize = true;
            this.kdc9.Location = new System.Drawing.Point(170, 504);
            this.kdc9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.kdc9.Name = "kdc9";
            this.kdc9.Size = new System.Drawing.Size(54, 19);
            this.kdc9.TabIndex = 48;
            this.kdc9.Text = "역사";
            this.kdc9.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 552);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(161, 15);
            this.label8.TabIndex = 49;
            this.label8.Text = "결과건수(한 개만 선택)";
            // 
            // pageSize50
            // 
            this.pageSize50.AutoSize = true;
            this.pageSize50.Location = new System.Drawing.Point(10, 571);
            this.pageSize50.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pageSize50.Name = "pageSize50";
            this.pageSize50.Size = new System.Drawing.Size(54, 19);
            this.pageSize50.TabIndex = 50;
            this.pageSize50.Text = "50건";
            this.pageSize50.UseVisualStyleBackColor = true;
            // 
            // pageSize100
            // 
            this.pageSize100.AutoSize = true;
            this.pageSize100.Location = new System.Drawing.Point(64, 571);
            this.pageSize100.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pageSize100.Name = "pageSize100";
            this.pageSize100.Size = new System.Drawing.Size(61, 19);
            this.pageSize100.TabIndex = 51;
            this.pageSize100.Text = "100건";
            this.pageSize100.UseVisualStyleBackColor = true;
            // 
            // pageSize200
            // 
            this.pageSize200.AutoSize = true;
            this.pageSize200.Location = new System.Drawing.Point(124, 571);
            this.pageSize200.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pageSize200.Name = "pageSize200";
            this.pageSize200.Size = new System.Drawing.Size(61, 19);
            this.pageSize200.TabIndex = 52;
            this.pageSize200.Text = "200건";
            this.pageSize200.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("D2Coding", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(12, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(225, 33);
            this.label9.TabIndex = 53;
            this.label9.Text = "인기 대출 도서";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rankingDataGridViewTextBoxColumn,
            this.booknameDataGridViewTextBoxColumn,
            this.authorsDataGridViewTextBoxColumn,
            this.publisherDataGridViewTextBoxColumn,
            this.publicationyearDataGridViewTextBoxColumn,
            this.loancountDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.popularityBookBindingSource;
            this.dataGridView1.GridColor = System.Drawing.Color.Gainsboro;
            this.dataGridView1.Location = new System.Drawing.Point(491, 29);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("D2Coding", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(647, 656);
            this.dataGridView1.TabIndex = 54;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(10, 656);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 29);
            this.button1.TabIndex = 55;
            this.button1.Text = "결과 보기";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rankingDataGridViewTextBoxColumn
            // 
            this.rankingDataGridViewTextBoxColumn.DataPropertyName = "ranking";
            this.rankingDataGridViewTextBoxColumn.HeaderText = "ranking";
            this.rankingDataGridViewTextBoxColumn.Name = "rankingDataGridViewTextBoxColumn";
            // 
            // booknameDataGridViewTextBoxColumn
            // 
            this.booknameDataGridViewTextBoxColumn.DataPropertyName = "bookname";
            this.booknameDataGridViewTextBoxColumn.HeaderText = "bookname";
            this.booknameDataGridViewTextBoxColumn.Name = "booknameDataGridViewTextBoxColumn";
            // 
            // authorsDataGridViewTextBoxColumn
            // 
            this.authorsDataGridViewTextBoxColumn.DataPropertyName = "authors";
            this.authorsDataGridViewTextBoxColumn.HeaderText = "authors";
            this.authorsDataGridViewTextBoxColumn.Name = "authorsDataGridViewTextBoxColumn";
            // 
            // publisherDataGridViewTextBoxColumn
            // 
            this.publisherDataGridViewTextBoxColumn.DataPropertyName = "publisher";
            this.publisherDataGridViewTextBoxColumn.HeaderText = "publisher";
            this.publisherDataGridViewTextBoxColumn.Name = "publisherDataGridViewTextBoxColumn";
            // 
            // publicationyearDataGridViewTextBoxColumn
            // 
            this.publicationyearDataGridViewTextBoxColumn.DataPropertyName = "publication_year";
            this.publicationyearDataGridViewTextBoxColumn.HeaderText = "publication_year";
            this.publicationyearDataGridViewTextBoxColumn.Name = "publicationyearDataGridViewTextBoxColumn";
            // 
            // loancountDataGridViewTextBoxColumn
            // 
            this.loancountDataGridViewTextBoxColumn.DataPropertyName = "loan_count";
            this.loancountDataGridViewTextBoxColumn.HeaderText = "loan_count";
            this.loancountDataGridViewTextBoxColumn.Name = "loancountDataGridViewTextBoxColumn";
            // 
            // popularityBookBindingSource
            // 
            this.popularityBookBindingSource.DataSource = typeof(AI3_A_Team_CSharp_Project.PopularityBook);
            // 
            // PopularityBookList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(1150, 792);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pageSize200);
            this.Controls.Add(this.pageSize100);
            this.Controls.Add(this.pageSize50);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.kdc9);
            this.Controls.Add(this.kdc8);
            this.Controls.Add(this.kdc7);
            this.Controls.Add(this.kdc6);
            this.Controls.Add(this.kdc5);
            this.Controls.Add(this.kdc4);
            this.Controls.Add(this.kdc3);
            this.Controls.Add(this.kdc2);
            this.Controls.Add(this.kdc1);
            this.Controls.Add(this.kdc0);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.checkBox30);
            this.Controls.Add(this.checkBox29);
            this.Controls.Add(this.checkBox28);
            this.Controls.Add(this.checkBox27);
            this.Controls.Add(this.checkBox26);
            this.Controls.Add(this.checkBox25);
            this.Controls.Add(this.checkBox24);
            this.Controls.Add(this.region32);
            this.Controls.Add(this.region31);
            this.Controls.Add(this.region29);
            this.Controls.Add(this.region26);
            this.Controls.Add(this.region25);
            this.Controls.Add(this.region24);
            this.Controls.Add(this.region23);
            this.Controls.Add(this.region22);
            this.Controls.Add(this.region21);
            this.Controls.Add(this.region11);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.gender2);
            this.Controls.Add(this.agem1);
            this.Controls.Add(this.age60);
            this.Controls.Add(this.age50);
            this.Controls.Add(this.age40);
            this.Controls.Add(this.age30);
            this.Controls.Add(this.age20);
            this.Controls.Add(this.age14);
            this.Controls.Add(this.age8);
            this.Controls.Add(this.age6);
            this.Controls.Add(this.age0);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.gender1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.date2);
            this.Controls.Add(this.date1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gender0);
            this.Font = new System.Drawing.Font("D2Coding", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PopularityBookList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PopularityBook";
            this.Load += new System.EventHandler(this.Lib2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popularityBookBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox gender0;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox date1;
        private System.Windows.Forms.TextBox date2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox gender1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox age0;
        private System.Windows.Forms.CheckBox age6;
        private System.Windows.Forms.CheckBox age8;
        private System.Windows.Forms.CheckBox age14;
        private System.Windows.Forms.CheckBox age20;
        private System.Windows.Forms.CheckBox age30;
        private System.Windows.Forms.CheckBox age40;
        private System.Windows.Forms.CheckBox age50;
        private System.Windows.Forms.CheckBox age60;
        private System.Windows.Forms.CheckBox agem1;
        private System.Windows.Forms.CheckBox gender2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox region11;
        private System.Windows.Forms.CheckBox region21;
        private System.Windows.Forms.CheckBox region22;
        private System.Windows.Forms.CheckBox region23;
        private System.Windows.Forms.CheckBox region24;
        private System.Windows.Forms.CheckBox region25;
        private System.Windows.Forms.CheckBox region26;
        private System.Windows.Forms.CheckBox region29;
        private System.Windows.Forms.CheckBox region31;
        private System.Windows.Forms.CheckBox region32;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox kdc0;
        private System.Windows.Forms.CheckBox kdc1;
        private System.Windows.Forms.CheckBox kdc2;
        private System.Windows.Forms.CheckBox kdc3;
        private System.Windows.Forms.CheckBox kdc4;
        private System.Windows.Forms.CheckBox kdc5;
        private System.Windows.Forms.CheckBox kdc6;
        private System.Windows.Forms.CheckBox kdc7;
        private System.Windows.Forms.CheckBox kdc8;
        private System.Windows.Forms.CheckBox kdc9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox pageSize50;
        private System.Windows.Forms.CheckBox pageSize100;
        private System.Windows.Forms.CheckBox pageSize200;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridViewTextBoxColumn rankingDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn booknameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn authorsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn publisherDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn publicationyearDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn loancountDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource popularityBookBindingSource;
    }
}

