﻿namespace AI3_A_Team_CSharp_Project
{
    internal class Dictiocary<T1, T2>
    {
    }
}